# hard_07 review

- Status: pending
- Notes:
