# hard_03 review

- Status: pending
- Notes:
